from pydantic import BaseModel, EmailStr, HttpUrl # type: ignore
from typing import Optional, List

class ChatbotCreate(BaseModel):
    name: str
    business_name: str
    industry: str
    website_url: Optional[HttpUrl] = None
    target_audience: Optional[str] = None
    language: str
    goal_of_chatbot: Optional[str] = None
    contact_email: EmailStr
    preferred_tone: Optional[str] = "friendly"
    auto_reply_keywords: Optional[List[str]] = []

class ChatbotUpdate(BaseModel):
    name: Optional[str] = None
    business_name: Optional[str] = None
    industry: Optional[str] = None
    website_url: Optional[HttpUrl] = None
    target_audience: Optional[str] = None
    language: Optional[str] = None
    goal_of_chatbot: Optional[str] = None
    contact_email: Optional[EmailStr] = None
    preferred_tone: Optional[str] = None
    auto_reply_keywords: Optional[List[str]] = None
# schemas.py

from pydantic import BaseModel # type: ignore

class AutoGenerateChatbotRequest(BaseModel):
    name: str | None = None   # optional, kyunki kabhi-kabhi sirf industry se generate karenge
    industry: str
# schemas.py

from pydantic import BaseModel # type: ignore
from typing import Optional
from datetime import datetime

class ChatbotListResponse(BaseModel):
    id: int
    chatbot_id: str
    name: str
    business_name: Optional[str]
    industry: Optional[str]
    website_url: Optional[str]
    target_audience: Optional[str]
    language: Optional[str]
    goal_of_chatbot: Optional[str]
    contact_email: Optional[str]
    preferred_tone: Optional[str]
    auto_reply_keywords: Optional[str]
    created_at: datetime

    class Config:
        orm_mode = True
