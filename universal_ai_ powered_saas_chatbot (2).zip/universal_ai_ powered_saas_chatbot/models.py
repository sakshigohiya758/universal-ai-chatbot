from sqlmodel import SQLModel, Field # type: ignore
from pydantic import EmailStr # type: ignore
from typing import Optional
from uuid import uuid4
from datetime import datetime

class Chatbot(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    chatbot_id: str = Field(default_factory=lambda: str(uuid4()), index=True)
    name: str
    business_name: str
    industry: str
    website_url: Optional[str] = None
    target_audience: Optional[str] = None
    language: str
    goal_of_chatbot: Optional[str] = None
    contact_email: EmailStr
    preferred_tone: Optional[str] = "friendly"
    auto_reply_keywords: Optional[str] = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
