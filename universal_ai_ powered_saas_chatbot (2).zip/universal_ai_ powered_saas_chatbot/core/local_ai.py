#import requests # type: ignore

#def chat_with_localai(prompt: str, chatbot_name: str = "LocalAI Chatbot") -> str:
#    try:
#        response = requests.post(
#            "http://localhost:11434/api/generate",
#            json={
#                "model": "mistral",  # ya "tinyllama" agar wo chalu hai
#                "prompt": prompt,
#                "stream": False
#            }
#        )
#        response.raise_for_status()
#        result = response.json()
#        return result.get("response", "No response from LocalAI.")
#    except Exception as e:
#        return f"❌ LocalAI Error: {str(e)}"
import subprocess

def chat_with_localai(prompt: str) -> str:
    try:
        # Run ollama command and capture output
        result = subprocess.run(
            ["ollama", "run", "neural-chat"],
            input=prompt.encode("utf-8"),
            capture_output=True,
            timeout=30
        )
        output = result.stdout.decode("utf-8")
        return output.strip()
    except Exception as e:
        return f"Error querying Neural Chat: {str(e)}"
