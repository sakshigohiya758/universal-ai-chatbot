import chatbot_routes
from fastapi import FastAPI # type: ignore
from fastapi.middleware.cors import CORSMiddleware # type: ignore

# Import your routers here
from routes.chatbot_routes import router as chatbot_router # type: ignore
from routes.ai_brain_router import router as ai_brain_router # type: ignore

app = FastAPI(
    title="Universal AI SaaS Chatbot",
    description="Fully Automated AI Chatbot System",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev use only; update in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Include all routers with prefix and tags
app.include_router(chatbot_routes, prefix="/chatbots/router", tags=["Chatbots (Router Based)"])
app.include_router(ai_brain_router, prefix="/", tags=["Developer Tools"])

# Optional root route
@app.get("/")
def read_root():
    return {"message": "Universal AI SaaS Chatbot API is running"}
from routes.ai_brain_routes import router as ai_brain_router # type: ignore
app.include_router(ai_brain_router, tags=["AI Brain"])
