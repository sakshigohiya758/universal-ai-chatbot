from ai_engine.llm_client import query_tinyllama

def generate_chatbot_from_industry(industry: str, bot_name: str, goal: str, audience: str, tone: str, features: list) -> dict:
    feature_list = ', '.join(features)
    prompt = f"""
    You are an expert chatbot designer.

    Create a chatbot config in JSON format.
    Industry: {industry}
    Bot Name: {bot_name}
    Goal: {goal}
    Audience: {audience}
    Tone: {tone}
    Features: {feature_list}
    """

    ai_response = query_tinyllama(prompt)

    try:
        import json
        return json.loads(ai_response)
    except Exception as e:
        return {
            "error": f"Failed to parse AI response: {ai_response}",
            "details": str(e)
        }
