# ai_engine/llm_client.py

import requests  # type: ignore

def query_tinyllama(prompt: str) -> str:
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "tinyllama",
                "prompt": prompt,
                "stream": False
            },
            timeout=30  # Important: timeout daal diya
        )
        
        response.raise_for_status()  # Directly error throw karega if not 2xx

        data = response.json()
        llm_reply = data.get("response") or data.get("output") or ""
        return llm_reply.strip() if llm_reply else "No valid response from LLM."
    
    except requests.exceptions.RequestException as e:
        return f"Error querying TinyLlama: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"
