# routers/flow_templates.py

industry_templates = {
    "fashion": {
        "greeting": "Welcome to {{store_name}}! Explore the latest in {{industry}}.",
        "faq": "Our most popular category is {{top_category}}. Can I help you with that?",
        "closing": "Thanks for visiting {{store_name}}. Come back soon!"
    },
    "real_estate": {
        "greeting": "Welcome to {{store_name}} – Your partner in {{industry}} listings!",
        "faq": "Looking for {{property_type}} in {{location}}? I can help!",
        "closing": "Hope you find your dream property with {{store_name}}."
    }
}
