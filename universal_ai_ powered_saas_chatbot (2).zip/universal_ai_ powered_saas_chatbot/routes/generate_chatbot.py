from fastapi import APIRouter, Depends, HTTPException # type: ignore
from sqlmodel import Session # type: ignore
from database import get_session
from models import Chatbot
from schemas import AutoGenerateChatbotRequest
from ai_engine.llm_client import query_tinyllama
import uuid
from datetime import datetime

router = APIRouter()

@router.post("/", tags=["Auto Generate Chatbot"])
def auto_generate_chatbot(data: AutoGenerateChatbotRequest, session: Session = Depends(get_session)):
    try:
        chatbot_id = str(uuid.uuid4())
        industry = data.industry
        name = data.name or f"AutoBot-{industry}"
        business_name = f"Auto Business ({industry})"

        # Build prompt for AI
        prompt = f"Generate a chatbot for {industry} industry. Give friendly responses."
        llm_response = query_tinyllama(prompt)

        # Save chatbot
        chatbot = Chatbot(
            chatbot_id=chatbot_id,
            name=name,
            business_name=business_name,
            industry=industry,
            website_url=None,
            target_audience=None,
            language="English",
            goal_of_chatbot="Auto-generated chatbot to assist users.",
            contact_email="auto-generated@chatbot.com",
            preferred_tone="friendly",
            auto_reply_keywords="",
            created_at=datetime.utcnow()
        )
        session.add(chatbot)
        session.commit()
        session.refresh(chatbot)

        return {
            "chatbot_id": chatbot_id,
            "industry": industry,
            "ai_message": llm_response
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
