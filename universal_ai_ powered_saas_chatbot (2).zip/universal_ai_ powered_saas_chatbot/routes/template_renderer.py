# routers/template_renderer.py

from typing import Dict
import re

def render_template(template: str, variables: Dict[str, str]) -> str:
    pattern = re.compile(r"\{\{(.*?)\}\}")

    def replacer(match):
        key = match.group(1).strip()
        return variables.get(key, f"<{key}-not-found>")

    return pattern.sub(replacer, template)
