from fastapi import APIRouter, Depends, HTTPException # type: ignore
from sqlmodel import Session, select # type: ignore

from database import get_session
from models import Chatbot
from schemas import ChatbotCreate, ChatbotUpdate

router = APIRouter(prefix="/chatbots/router", tags=["Chatbots (Router Based)"])

# Create a new chatbot
@router.post("/", response_model=Chatbot)
def create_chatbot(chatbot: ChatbotCreate, session: Session = Depends(get_session)):
    new_chatbot = Chatbot(
        **chatbot.dict(exclude={"auto_reply_keywords", "website_url"}),
        website_url=str(chatbot.website_url) if chatbot.website_url else None,
        auto_reply_keywords=",".join(chatbot.auto_reply_keywords),
    )
    session.add(new_chatbot)
    session.commit()
    session.refresh(new_chatbot)
    return new_chatbot

# Get chatbot by ID
@router.get("/{chatbot_id}", response_model=Chatbot)
def read_chatbot(chatbot_id: str, session: Session = Depends(get_session)):
    chatbot = session.exec(select(Chatbot).where(Chatbot.chatbot_id == chatbot_id)).first()
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    return chatbot

# Update chatbot by ID
@router.put("/{chatbot_id}", response_model=Chatbot)
def update_chatbot(chatbot_id: str, chatbot_update: ChatbotUpdate, session: Session = Depends(get_session)):
    chatbot = session.exec(select(Chatbot).where(Chatbot.chatbot_id == chatbot_id)).first()
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")

    update_data = chatbot_update.dict(exclude_unset=True)
    if "auto_reply_keywords" in update_data:
        update_data["auto_reply_keywords"] = ",".join(update_data["auto_reply_keywords"])
    if "website_url" in update_data and update_data["website_url"]:
        update_data["website_url"] = str(update_data["website_url"])

    for key, value in update_data.items():
        setattr(chatbot, key, value)

    session.add(chatbot)
    session.commit()
    session.refresh(chatbot)
    return chatbot

# Delete chatbot by ID
@router.delete("/{chatbot_id}")
def delete_chatbot(chatbot_id: str, session: Session = Depends(get_session)):
    chatbot = session.exec(select(Chatbot).where(Chatbot.chatbot_id == chatbot_id)).first()
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")

    session.delete(chatbot)
    session.commit()
    return {"message": f"Chatbot with ID {chatbot_id} deleted successfully."}
