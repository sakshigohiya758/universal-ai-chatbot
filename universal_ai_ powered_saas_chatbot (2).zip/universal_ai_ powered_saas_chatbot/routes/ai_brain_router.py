from fastapi import APIRouter # type: ignore

router = APIRouter()

# Health check for AI Brain
@router.get("/ai-brain/ping")
def ping_ai_brain():
    return {"message": "AI Brain is active and ready!"}

# Placeholder for future AI brain logic
@router.post("/ai-brain/process")
def process_brain_logic(data: dict):
    # You can add AI logic here later
    return {"status": "received", "input": data}
# routers/ai_brain_router.py

from fastapi import APIRouter # type: ignore
from routers.flow_templates import industry_templates # type: ignore
from routers.template_renderer import render_template # type: ignore

router = APIRouter()

@router.post("/auto-generate-flow")
def generate_flow(industry: str, store_name: str = "Your Business", top_category: str = "", property_type: str = "", location: str = ""):
    if industry not in industry_templates:
        return {"error": "Industry not supported yet."}

    variables = {
        "store_name": store_name,
        "industry": industry,
        "top_category": top_category,
        "property_type": property_type,
        "location": location
    }

    template = industry_templates[industry]
    rendered_flow = {key: render_template(text, variables) for key, text in template.items()}
    
    return {
        "chatbot_flow": rendered_flow,
        "industry": industry
    }
@router.post("/test-generate-prompt")
def test_generate_prompt():
    chatbot_flow = {
        "greeting": "Welcome to Stylish Curve! Explore the latest in fashion.",
        "faq": "Our most popular category is Plus-size Dresses. Can I help you with that?",
        "closing": "Thanks for visiting Stylish Curve. Come back soon!"
    }
    user_message = "Do you have party wear in XL?"
    industry = "fashion"

    # Prompt builder logic (without separate file)
    prompt = f"You are a helpful chatbot for a {industry} business.\n\n"
    for key, value in chatbot_flow.items():
        prompt += f"{key.capitalize()}: {value}\n"
    prompt += f"\nNow, respond to this message:\n\"{user_message}\""

    return {"prompt": prompt}
from fastapi import APIRouter # type: ignore
from pydantic import BaseModel # type: ignore
from core.local_ai import query_neural_chat

router = APIRouter()

class PromptRequest(BaseModel):
    prompt: str

@router.post("/generate-chatbot")
def generate_chatbot(request: PromptRequest):
    response = query_neural_chat(request.prompt)
    return {"ai_response": response}
