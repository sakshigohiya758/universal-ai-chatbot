from fastapi import APIRouter, HTTPException, Depends # type: ignore
from sqlmodel import Session, select # type: ignore
from database import get_session
from models import Chatbot  # Imported Chatbot model from models.py

router = APIRouter()

@router.delete("/chatbots/{chatbot_id}", tags=["Chatbots"])
def delete_chatbot(chatbot_id: str, session: Session = Depends(get_session)):
    chatbot = session.exec(select(Chatbot).where(Chatbot.chatbot_id == chatbot_id)).first()
    if chatbot:
        session.delete(chatbot)
        session.commit()
        return {"message": f"Chatbot with ID {chatbot_id} has been deleted successfully."}
    else:
        raise HTTPException(status_code=404, detail="Chatbot not found")
