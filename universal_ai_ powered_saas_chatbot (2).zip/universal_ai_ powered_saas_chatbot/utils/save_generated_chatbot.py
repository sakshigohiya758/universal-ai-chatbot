# utils/save_generated_chatbot.py

import uuid
from sqlmodel import Session # type: ignore
from models import Chatbot

def save_generated_chatbot(
    session: Session,
    industry: str,
    bot_name: str,
    goal: str,
    audience: str,
    tone: str,
    features: list,
    flow: dict,
    contact_email: str = "auto-generated@chatbot.com"  # Default email
) -> Chatbot:
    new_chatbot = Chatbot(
        chatbot_id=str(uuid.uuid4()),
        bot_name=bot_name,
        industry=industry,
        goal=goal,
        audience=audience,
        tone=tone,
        features=",".join(features),
        flow=flow,
        contact_email=contact_email
    )
    session.add(new_chatbot)
    session.commit()
    session.refresh(new_chatbot)
    return new_chatbot
