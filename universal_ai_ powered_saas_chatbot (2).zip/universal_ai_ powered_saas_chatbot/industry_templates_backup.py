# industry_templates.py (Template for different industries)

industry_templates = {
    "E-commerce": {
        "welcome_message": "Welcome to our online store! How can I assist you today?",
        "greeting": "Hi, how can I help you with your shopping experience?",
        "help": "I can help you with product recommendations, order tracking, and more.",
        "faq": {
            "payment_methods": "We accept credit cards, PayPal, and more.",
            "shipping": "We offer worldwide shipping with tracking."
        },
        "end_conversation": "Thank you for visiting! Feel free to return anytime."
    },
    "Doctor Appointment": {
        "welcome_message": "Welcome to our clinic! How can I assist you today?",
        "greeting": "Hi! What can I help you with regarding your appointment?",
        "help": "I can help you book, reschedule, or cancel an appointment.",
        "faq": {
            "working_hours": "We are open Monday to Friday, 9 AM - 5 PM.",
            "contact_info": "You can reach us at 123-456-7890."
        },
        "end_conversation": "Thank you for choosing our clinic. Take care!"
    },
    "Real Estate": {
        "welcome_message": "Welcome to our real estate agency! How can I help you?",
        "greeting": "Hi! Are you looking for a new property to buy or rent?",
        "help": "I can assist you with listings, scheduling property viewings, and more.",
        "faq": {
            "price_range": "Our properties range from $200,000 to $2,000,000.",
            "location": "We have properties in downtown, suburbs, and countryside."
        },
        "end_conversation": "Thank you for considering our agency. Hope to see you soon!"
    }
}
